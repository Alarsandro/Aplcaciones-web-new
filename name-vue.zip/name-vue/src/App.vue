<script >



export default {
  name: "app",
  data() {
    return {
      drawer: false,
      items: [
        { label: "Home", to: "/home" },
        { label: "HealthChecks", to: "/analytics/health-checks" },
      ],
    };
  },
};
</script>


<template class="">

  <header>
    <pv-toolbar class="bg-gray-800">
      <template #start>

        <div class="branding">TechnoGym TechnoRun Analytics</div>
      </template>


<template #center>
        <div class="flex-column ">
          <router-link
              v-for="item in items"
              :to="item.to"
              custom
              v-slot="{ navigate, href }"
              :key="item.label"
          >
            <pv-button class="p-button-text text-white bg-gray-800"
                       :href="href"
                       @click="navigate">
              {{ item.label }}
            </pv-button>
          </router-link>
        </div>
      </template>


    </pv-toolbar>
  </header>

  <pv-sidebar v-model:visible="drawer"> </pv-sidebar>
  <RouterView />
</template>

<style scoped>

</style>
